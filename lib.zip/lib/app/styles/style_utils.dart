import 'package:flutter/material.dart';

TextStyle extend(TextStyle s1, TextStyle s2) {
  return s1.merge(s2);
}
