class RepeatDuration {
  int month;
  String monthText;
  RepeatDuration({
    required this.month,
    required this.monthText,
  });
}
