const Map<String, String> ur = {
  'App Name': 'Hallo Doctor',
};
