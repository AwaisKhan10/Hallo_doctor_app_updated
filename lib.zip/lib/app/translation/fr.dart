const Map<String, String> fr = {
  'App Name': 'Hallo Doctor',
};
